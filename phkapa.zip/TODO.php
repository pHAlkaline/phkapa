//TODO Add company information
//TODO Add company UI costumization
//TODO Correct dashboard image text to "Corrective Action Preventive Action"
//TODO hints on form fields
//TODO write good documentation / wiki
//TODO Add to wiki , database edition
//TODO Add to wiki warning that on Verification ticket must be saved once
//TODO Remove comments from PO files
//TODO Remove spinner flash

