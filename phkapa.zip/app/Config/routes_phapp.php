<?php
/*if (file_exists(TMP.'installed.txt')) {
    // the routes for when the application has been installed
    //echo "installed";
} else {
    //echo "install";
    Router::connect('/:controler/:action', array('controller' => 'install'));
}*/
 