<?php
class PhkapaAppHelper extends AppHelper {
}
?>
